package app;
import java.io.*;
import java.util.ArrayList;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class AdminServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String key = req.getParameter("key");
        if (!"admin123".equals(key)) { resp.sendError(403); return; }

        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        
        out.println("<h1>🕵️ God Mode</h1>");
        
        // 1. PUBLIC ROOM
        out.println("<h3>🌍 Public Room</h3>");
        printFiles(out, RoomManager.publicRoom);

        // 2. PRIVATE ROOMS
        ArrayList<Object> allRooms = RoomManager.getAllRoomsForAdmin();
        out.println("<h3>🔒 Active Private Rooms: " + allRooms.size() + "</h3>");
        
        int count = 1;
        for (Object obj : allRooms) {
            Room r = (Room) obj;
            out.println("<div style='border:1px solid #ccc; margin:10px; padding:10px;'>");
            out.println("<b>Room #" + count++ + "</b><br>");
            printFiles(out, r);
            out.println("</div>");
        }
    }

    private void printFiles(PrintWriter out, Room room) {
        FileNode cur = room.files.getHead();
        if (cur == null) { out.println("<i>(Empty)</i><br>"); return; }
        while (cur != null) {
            out.println("📄 " + cur.fileName + "<br>");
            cur = cur.next;
        }
    }
}