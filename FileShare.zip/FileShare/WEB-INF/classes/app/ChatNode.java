package app;

public class ChatNode {
    public String message;
    public ChatNode next;

    public ChatNode(String message) {
        this.message = message;
        this.next = null;
    }
}