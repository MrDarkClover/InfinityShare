package app;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@MultipartConfig
public class ChunkUploadServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // 1. Get Params
        Part filePart = request.getPart("file");
        String fileName = request.getParameter("fileName");
        String roomType = request.getParameter("roomType"); // "public" or "private"
        String roomCode = request.getParameter("roomCode");
        boolean isLast = Boolean.parseBoolean(request.getParameter("isLast"));

        // 2. Write Chunk to Temp File
        String uploadPath = getServletContext().getRealPath("/files");
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdir();

        File tempFile = new File(uploadDir, fileName + ".temp");
        
        try (FileOutputStream fos = new FileOutputStream(tempFile, true);
             InputStream is = filePart.getInputStream()) {
            byte[] buffer = new byte[1024 * 1024];
            int r;
            while ((r = is.read(buffer)) != -1) fos.write(buffer, 0, r);
        }

        // 3. Finalize if Last Chunk
        if (isLast) {
            File finalFile = new File(uploadDir, fileName);
            // Rename logic to prevent overwriting
            if (finalFile.exists()) {
                finalFile = new File(uploadDir, System.currentTimeMillis() + "_" + fileName);
            }
            tempFile.renameTo(finalFile);

            // --- FIX IS HERE ---
            // We use the new RoomManager.getRoom() method
            String targetCode = "public";
            if ("private".equals(roomType) && roomCode != null && !roomCode.isEmpty()) {
                targetCode = roomCode;
            }

            // Get the Room object (which holds files AND chat)
            Room room = RoomManager.getRoom(targetCode);
            
            if (room != null) {
                // Add file to the room's file list
                room.files.addFile(finalFile.getName());
            }
            
            response.getWriter().write("COMPLETE");
        } else {
            response.getWriter().write("CHUNK_SAVED");
        }
    }
}