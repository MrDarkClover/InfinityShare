package app;
public class CustomFileList {
    private FileNode head;

    public CustomFileList() {
        this.head = null;
    }

    // Add a file to the end of the list
    public void addFile(String name) {
        FileNode newNode = new FileNode(name);
        if (head == null) {
            head = newNode;
        } else {
            FileNode current = head;
            // Traverse to the end
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Get the start of the list so we can loop through it later
    public FileNode getHead() {
        return head;
    }
}