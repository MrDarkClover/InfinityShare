package app;

import java.util.ArrayList; // Used only for Admin Dashboard reporting

public class CustomHashMap {
    private MapNode[] buckets;
    private int capacity;

    public CustomHashMap() {
        this.capacity = 100; 
        this.buckets = new MapNode[capacity];
    }

    private int getBucketIndex(String key) {
        int hashCode = 0;
        for (int i = 0; i < key.length(); i++) {
            hashCode += key.charAt(i);
        }
        return hashCode % capacity;
    }

    // UPDATED: Accepts Object value (Room)
    public void put(String key, Object value) {
        int index = getBucketIndex(key);
        MapNode head = buckets[index];

        while (head != null) {
            if (head.key.equals(key)) {
                head.value = value;
                return;
            }
            head = head.next;
        }

        head = buckets[index];
        MapNode newNode = new MapNode(key, value);
        newNode.next = head;
        buckets[index] = newNode;
    }

    // UPDATED: Returns Object (needs casting to Room later)
    public Object get(String key) {
        int index = getBucketIndex(key);
        MapNode head = buckets[index];

        while (head != null) {
            if (head.key.equals(key)) {
                return head.value;
            }
            head = head.next;
        }
        return null;
    }

    public boolean containsKey(String key) {
        return get(key) != null;
    }

    // --- NEW: Helper for Admin Dashboard ---
    // Returns a list of all Rooms so Admin can see them
    public ArrayList<Object> getAllValues() {
        ArrayList<Object> list = new ArrayList<>();
        for (int i = 0; i < capacity; i++) {
            MapNode head = buckets[i];
            while (head != null) {
                list.add(head.value);
                head = head.next;
            }
        }
        return list;
    }
}