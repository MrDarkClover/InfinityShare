package app;

public class FileNode {
    public String fileName;
    public FileNode next;

    public FileNode(String fileName) {
        this.fileName = fileName;
        this.next = null;
    }
}