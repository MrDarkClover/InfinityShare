package app;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class HomeServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String currentRoomCode = (String) session.getAttribute("privateRoomCode");
        
        // 1. Determine which room the user is in
        String roomKey = (currentRoomCode != null) ? currentRoomCode : "public";
        
        // 2. Get the Room Object
        // (Note: getRoom handles "public" string internally if you implemented it as I showed)
        Room currentRoom = RoomManager.getRoom(roomKey);

        // 3. Send Room Data to JSP
        request.setAttribute("currentRoom", currentRoom);
        
        // Pass room code specifically for the UI logic
        if (currentRoomCode != null) {
            request.setAttribute("inPrivateRoom", true);
            request.setAttribute("roomCode", currentRoomCode);
        } else {
            request.setAttribute("inPrivateRoom", false);
        }

        // 4. Forward to the UI
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        HttpSession session = request.getSession();

        if ("createPrivate".equals(action)) {
            String newCode = RoomManager.createPrivateRoom();
            session.setAttribute("privateRoomCode", newCode);
        } 
        else if ("joinPrivate".equals(action)) {
            String code = request.getParameter("code");
            // Check if room exists
            if (RoomManager.getRoom(code) != null) {
                session.setAttribute("privateRoomCode", code);
            }
        }
        else if ("exitPrivate".equals(action)) {
            session.removeAttribute("privateRoomCode");
        }
        else if ("sendChat".equals(action)) {
            // --- NEW CHAT LOGIC ---
            String msg = request.getParameter("message");
            String roomCode = (String) session.getAttribute("privateRoomCode");
            
            // If roomCode is null, we are in public room
            String targetRoom = (roomCode != null) ? roomCode : "public";
            
            Room room = RoomManager.getRoom(targetRoom);
            
            if (room != null && msg != null && !msg.trim().isEmpty()) {
                room.addMessage(msg);
            }
        }

        response.sendRedirect("home");
    }
}