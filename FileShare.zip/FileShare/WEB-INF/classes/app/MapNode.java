package app;

public class MapNode {
    public String key;
    public Object value; // Changed to Object so it can hold a Room
    public MapNode next;

    public MapNode(String key, Object value) {
        this.key = key;
        this.value = value;
        this.next = null;
    }
}