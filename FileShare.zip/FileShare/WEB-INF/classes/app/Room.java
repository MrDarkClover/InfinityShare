package app;

public class Room {
    public CustomFileList files;
    public ChatNode chatHead; // Start of the Chat Linked List
    public ChatNode chatTail; // End of the Chat (for fast insertion)

    public Room() {
        this.files = new CustomFileList();
        this.chatHead = null;
        this.chatTail = null;
    }

    // O(1) Insertion for Chat
    public void addMessage(String msg) {
        ChatNode newNode = new ChatNode(msg);
        if (chatHead == null) {
            chatHead = newNode;
            chatTail = newNode;
        } else {
            chatTail.next = newNode;
            chatTail = newNode;
        }
    }
}