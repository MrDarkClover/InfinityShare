package app;

import java.util.Random;
import java.util.ArrayList;

public class RoomManager {
    // Public Room (Static)
    public static Room publicRoom = new Room();

    // Private Rooms (Custom Hash Map)
    private static CustomHashMap privateRooms = new CustomHashMap();

    public static String createPrivateRoom() {
        Random rand = new Random();
        int code = 100000 + rand.nextInt(900000); 
        String roomCode = String.valueOf(code);
        
        // Put the new ROOM object into the map
        privateRooms.put(roomCode, new Room());
        return roomCode;
    }

    public static Room getRoom(String code) {
        if (code == null || "public".equals(code)) return publicRoom;
        
        // CAST the Object back to a Room
        return (Room) privateRooms.get(code);
    }
    
    // For Admin Dashboard
    public static ArrayList<Object> getAllRoomsForAdmin() {
        return privateRooms.getAllValues();
    }
}