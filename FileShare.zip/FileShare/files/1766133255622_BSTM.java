import java.util.Scanner;

public class BSTM {
    static class Node{
        int data;
        Node left,right;
        Node(int data){
            this.data=data;
            left=right=null;
        }
    }
    static class BST{
        Node root;

        Node insert(Node root,int key){
            if(root == null)
                return new Node(key);
            if(key<root.data)
                root.left=insert(root.left, key);
            else if (key>root.data)
                root.right=insert(root.right, key);

            return root;
        }
        void insertMultiple(int[] values){
            for(int value: values){
                root=insert(root, value);
                System.out.println("All Values inserted successully.");
            }
        }
        Node delete(Node root, int key){
            if (root == null) {
                System.out.println("value not found in a tree");
                return null;
            }
            if (key<root.data) 
                root.left=delete(root.left, key);
            else if (key>root.data)
                root.right=delete(root.right, key);
            else{
                if (root.left==null) return root.left;
                if (root.right==null) return root.right;

                root.data=findMin(root.right);
                root.right=delete(root.right, root.data);
                System.out.println("data deleted successully.");
            } 
            return root;
        }
        int findMin(Node root){
            if (root==null) return -1;
            while (root.left!=null) {
                root=root.left;
            }return root.data;
        }
        int findMax(Node root){
            if (root==null) return -1;
            while (root.right!=null) {
                root=root.right;
            }return root.data;
        }
        int height(Node root){
            if (root==null) return -1;
            return 1+ Math.max(height(root.left), height(root.right));
        }
        boolean isEmpty(){
            return root == null;
        }
        void inorder(Node root){
            if (root != null) {
                inorder(root.left);
                System.out.println(root.data+" ");
                inorder(root.right);
            }
        }
        void preorder(Node root){
            if (root != null) {
                System.out.println(root.data+" ");
                preorder(root.left);
                preorder(root.right);
            }
        }
        void postorder(Node root){
            if (root != null) {
                postorder(root.left);
                postorder(root.right);
                System.out.println(root.data+" ");
            }
        }
        void displayTree(Node root,int space){
            if (root == null) return;
            space+=10;
            displayTree(root.right, space);
            System.out.println();
            for(int i=10;i<space;i++){
                System.out.println(" ");
            }
            System.out.println(root.data);
            displayTree(root.left, space);
        }
    }
    public static void main(String[] args) {
        BST tree = new BST();
        Scanner sc= new Scanner(System.in);
        int choice;

        while (true) {
            System.out.println("-------Menu-------");
            System.out.println("1.insert");
            System.out.println("2.delete");
            System.out.println("3.height");
            System.out.println("4.indMin");
            System.out.println("5.indMax");
            System.out.println("6.preorder");
            System.out.println("7.inorder");
            System.out.println("8.postorder");
            System.out.println("9.displsy");
            System.out.println("10.Exit");

            System.out.println("Enter the choice: ");
            choice=sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Enter the number to be insertd: ");
                    int n=sc.nextInt();
                    int[] values=new int[n];
                    System.out.println("Enter the values: ");
                    for(int i=0;i<n;i++)
                    {
                        values[i]=sc.nextInt();
                    }
                    tree.insertMultiple(values);
                    break;
                case 2:
                    if (tree.isEmpty()) {System.out.println("tree is empty."); break;}
                    System.out.println("Enter value delete: ");
                    int del=sc.nextInt();
                    tree.root=tree.delete(tree.root, del);
                    break;
                case 3:
                    if (tree.isEmpty()) {System.out.println("tree is empty."); break;}
                    System.out.println("height: "+tree.height(tree.root));
                    break;
                case 4:
                    if (tree.isEmpty()) {System.out.println("tree is empty."); break;}
                    System.out.println("Min: "+tree.findMin(tree.root));
                    break;
                    case 5:
                    if (tree.isEmpty()) {System.out.println("tree is empty."); break;}
                    System.out.println("Max: "+tree.findMax(tree.root));
                    break;
                case 6:
                    if (tree.isEmpty()) {System.out.println("tree is empty."); break;}
                    System.out.println("preorder: ");
                    tree.preorder(tree.root);
                    System.out.println();
                    break;
                case 7:
                     if (tree.isEmpty()) {System.out.println("tree is empty."); break;}
                    System.out.println("inorder: ");
                    tree.inorder(tree.root);
                    System.out.println();
                    break;
                case 8:
                     if (tree.isEmpty()) {System.out.println("tree is empty."); break;}
                    System.out.println("postorder: ");
                    tree.postorder(tree.root);
                    System.out.println();
                    break;
                case 9:
                     if (tree.isEmpty()) {System.out.println("tree is empty."); break;}
                    System.out.println("display: ");
                    tree.displayTree(tree.root,0);
                    break;
                case 10:
                    System.out.println("Exit.....");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice.");
                    break;
            }


        }
    }
}
