package app;
import java.io.*;
import java.util.Arrays;
import java.util.List;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@MultipartConfig
public class ChunkUploadServlet extends HttpServlet {

    // 1. BLOCKLIST: Files that can destroy your server
    private static final List<String> BLOCKED_EXTENSIONS = Arrays.asList(
        ".exe", ".bat", ".sh", ".jsp", ".jspx", ".php", ".py", ".pl", ".cmd", ".vbs", ".msi"
    );

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        Part filePart = request.getPart("file");
        String rawFileName = request.getParameter("fileName");
        
        // --- SECURITY CHECK 1: Sanitize Filename ---
        // This removes "../" to prevent hackers from escaping the folder
        String fileName = new File(rawFileName).getName(); 

        // --- SECURITY CHECK 2: Block Runnable Files ---
        String lowerName = fileName.toLowerCase();
        for (String ext : BLOCKED_EXTENSIONS) {
            if (lowerName.endsWith(ext)) {
                response.setStatus(403); // Forbidden
                response.getWriter().write("ERROR: File type not allowed for security reasons.");
                return;
            }
        }

        // Continue with normal logic...
        String roomType = request.getParameter("roomType"); 
        String roomCode = request.getParameter("roomCode");
        boolean isLast = Boolean.parseBoolean(request.getParameter("isLast"));

        String uploadPath = getServletContext().getRealPath("/files");
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdir();

        // Save as .temp first
        File tempFile = new File(uploadDir, fileName + ".temp");
        
        try (FileOutputStream fos = new FileOutputStream(tempFile, true);
             InputStream is = filePart.getInputStream()) {
            byte[] buffer = new byte[1024 * 1024];
            int r;
            while ((r = is.read(buffer)) != -1) fos.write(buffer, 0, r);
        }

        if (isLast) {
            File finalFile = new File(uploadDir, fileName);
            // Prevent overwriting existing files
            if (finalFile.exists()) {
                finalFile = new File(uploadDir, System.currentTimeMillis() + "_" + fileName);
            }
            tempFile.renameTo(finalFile);

            if ("public".equals(roomType)) {
                RoomManager.publicFiles.addFile(finalFile.getName());
            } else if ("private".equals(roomType)) {
                CustomFileList list = RoomManager.getPrivateFiles(roomCode);
                if (list != null) list.addFile(finalFile.getName());
            }
            response.getWriter().write("COMPLETE");
        } else {
            response.getWriter().write("CHUNK_SAVED");
        }
    }
}