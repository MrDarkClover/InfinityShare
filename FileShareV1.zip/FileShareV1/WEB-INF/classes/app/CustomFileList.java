package app;

public class CustomFileList {
    public FileNode head;

    public CustomFileList() {
        this.head = null;
    }

    public void addFile(String fileName) {
        FileNode newNode = new FileNode(fileName);
        if (head == null) {
            head = newNode;
        } else {
            FileNode current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // --- THIS WAS MISSING ---
    public boolean deleteFile(String fileName) {
        if (head == null) return false;

        // Case 1: Delete Head
        if (head.fileName.equals(fileName)) {
            head = head.next;
            return true;
        }

        // Case 2: Delete Middle/Last
        FileNode current = head;
        while (current.next != null) {
            if (current.next.fileName.equals(fileName)) {
                current.next = current.next.next; // Skip the node
                return true;
            }
            current = current.next;
        }
        return false; // Not found
    }

    public FileNode getHead() {
        return head;
    }
}