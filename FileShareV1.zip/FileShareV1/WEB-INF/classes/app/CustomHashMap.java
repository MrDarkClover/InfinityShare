package app;

public class CustomHashMap {
    private MapNode[] buckets;
    private int capacity;

    public CustomHashMap() {
        this.capacity = 100; // Fixed size (100 buckets) for simplicity
        this.buckets = new MapNode[capacity];
    }

    // Hash Function: Converts "123456" into an index (0-99)
    private int getBucketIndex(String key) {
        int hashCode = 0;
        for (int i = 0; i < key.length(); i++) {
            hashCode += key.charAt(i);
        }
        return Math.abs(hashCode % capacity);
    }

    // PUT: Adds a new Room (Key: Code, Value: FileList)
    public void put(String key, CustomFileList value) {
        int index = getBucketIndex(key);
        MapNode head = buckets[index];

        // 1. Update existing key if found
        while (head != null) {
            if (head.key.equals(key)) {
                head.value = value;
                return;
            }
            head = head.next;
        }

        // 2. Insert new node at the beginning of the bucket (Collision Handling)
        head = buckets[index];
        MapNode newNode = new MapNode(key, value);
        newNode.next = head;
        buckets[index] = newNode;
    }

    public void remove(String key) {
        int index = getBucketIndex(key);
        MapNode head = buckets[index];
        MapNode prev = null;

        while (head != null) {
            if (head.key.equals(key)) {
                if (prev == null) buckets[index] = head.next;
                else prev.next = head.next;
                return;
            }
            prev = head;
            head = head.next;
        }
    }

    // GET: Retrieve the FileList for a specific Room Code
    public CustomFileList get(String key) {
        int index = getBucketIndex(key);
        MapNode head = buckets[index];

        while (head != null) {
            if (head.key.equals(key)) {
                return head.value;
            }
            head = head.next;
        }
        return null; // Room not found
    }

    // CONTAINS: Check if a room exists
    public boolean containsKey(String key) {
        return get(key) != null;
    }
}