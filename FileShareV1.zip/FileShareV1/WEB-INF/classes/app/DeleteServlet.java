package app;
import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class DeleteServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String fileName = request.getParameter("file");
        String roomCode = request.getParameter("roomCode"); // Null if public
        
        // 1. Delete from Disk (Physical)
        File file = new File(getServletContext().getRealPath("/files"), fileName);
        if (file.exists()) {
            file.delete();
        }

        // 2. Delete from DSA (Logical)
        if (roomCode != null && !roomCode.isEmpty() && !"null".equals(roomCode)) {
            // Private Room Delete
            CustomFileList list = RoomManager.getPrivateFiles(roomCode);
            if (list != null) list.deleteFile(fileName);
        } else {
            // Public Room Delete
            RoomManager.publicFiles.deleteFile(fileName);
        }

        response.sendRedirect("home");
    }
}