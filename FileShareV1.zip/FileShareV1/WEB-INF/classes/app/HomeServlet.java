package app;
import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class HomeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String currentRoom = (String) session.getAttribute("privateRoomCode");
        
        // Always load public files
        request.setAttribute("publicList", RoomManager.publicFiles);

        if (currentRoom != null) {
            // Check if room still exists
            if (!RoomManager.roomExists(currentRoom)) {
                session.removeAttribute("privateRoomCode");
                request.setAttribute("inPrivateRoom", false);
                request.setAttribute("error", "Session Expired: Room no longer exists.");
            } else {
                request.setAttribute("inPrivateRoom", true);
                request.setAttribute("roomCode", currentRoom);
                request.setAttribute("privateList", RoomManager.getPrivateFiles(currentRoom));
                request.setAttribute("isTemp", RoomManager.isTemporary(currentRoom));
            }
        } else {
            request.setAttribute("inPrivateRoom", false);
        }

        request.getRequestDispatcher("index.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        HttpSession session = request.getSession();

        try {
            if ("createPrivate".equals(action)) {
                String type = request.getParameter("type"); 
                boolean isTemp = "temp".equals(type);
                String code = RoomManager.createPrivateRoom(isTemp);
                session.setAttribute("privateRoomCode", code);
            } 
            else if ("joinPrivate".equals(action)) {
                String code = request.getParameter("code");
                if (RoomManager.roomExists(code)) {
                    session.setAttribute("privateRoomCode", code);
                } else {
                    // --- ERROR HANDLING FIX ---
                    request.setAttribute("error", "❌ Room Not Found: " + code);
                    request.setAttribute("publicList", RoomManager.publicFiles); 
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                    return; // Stop here, do not redirect
                }
            }
            else if ("exitPrivate".equals(action)) {
                String currentCode = (String) session.getAttribute("privateRoomCode");
                
                // --- PERSISTENCE FIX ---
                // Only delete if it is explicitly marked as Temporary
                if (currentCode != null && RoomManager.isTemporary(currentCode)) {
                    RoomManager.deleteRoom(currentCode);
                }
                
                session.removeAttribute("privateRoomCode");
            }
            
            response.sendRedirect("home");

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Server Error: " + e.getMessage());
            request.setAttribute("publicList", RoomManager.publicFiles);
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }
}