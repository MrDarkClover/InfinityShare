package app;

public class MapNode {
    public String key;
    public CustomFileList value;
    public MapNode next;

    public MapNode(String key, CustomFileList value) {
        this.key = key;
        this.value = value;
        this.next = null;
    }
}