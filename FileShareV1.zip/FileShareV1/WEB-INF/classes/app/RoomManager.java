package app;
import java.util.Random;
import java.util.HashSet;
import java.util.Set;

public class RoomManager {
    // 1. PUBLIC ROOM (Always Alive)
    public static CustomFileList publicFiles = new CustomFileList();

    // 2. PRIVATE ROOMS STORAGE
    private static CustomHashMap privateRooms = new CustomHashMap();
    
    // 3. TEMP ROOM TRACKER
    private static Set<String> tempRoomCodes = new HashSet<>();

    public static String createPrivateRoom(boolean isTemporary) {
        Random rand = new Random();
        int code = 100000 + rand.nextInt(900000); 
        String roomCode = String.valueOf(code);
        
        // Ensure code is unique
        while(privateRooms.containsKey(roomCode)) {
            code = 100000 + rand.nextInt(900000); 
            roomCode = String.valueOf(code);
        }

        // Initialize empty file list for this room
        privateRooms.put(roomCode, new CustomFileList());
        
        if (isTemporary) {
            tempRoomCodes.add(roomCode);
        }
        return roomCode;
    }

    public static CustomFileList getPrivateFiles(String roomCode) {
        return privateRooms.get(roomCode);
    }

    public static boolean roomExists(String roomCode) {
        return privateRooms.containsKey(roomCode);
    }
    
    public static boolean isTemporary(String roomCode) {
        return tempRoomCodes.contains(roomCode);
    }

    public static void deleteRoom(String roomCode) {
        if(roomCode == null) return;
        privateRooms.remove(roomCode);
        tempRoomCodes.remove(roomCode);
    }
}